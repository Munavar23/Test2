﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace Tcp_Server
{
    class Program
    {
        static void Main()
        {
            const int port = 12345;
            TcpListener server = null;

            try
            {
                server = new TcpListener(IPAddress.Loopback, port);
                server.Start();

                Console.WriteLine($"Server listening on 127.0.0.1:{port}...");
                Console.WriteLine("Waiting for a connection...");

                while (true)
                {
                    TcpClient client = server.AcceptTcpClient();
                    Console.WriteLine("Client connected!");

                    NetworkStream stream = client.GetStream();

                    // Start a new thread to handle client communication
                    Thread clientThread = new Thread(() => HandleClient(stream, client));
                    clientThread.Start();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine($"Exception: {e.Message}");
            }
            finally
            {
                server?.Stop();
            }
        }
        static void HandleClient(NetworkStream stream, TcpClient client)
        {
            byte[] buffer = new byte[1024];
            try
            {
                while (client.Connected)
                {
                    // Check if data is available to read
                    string received="";
                    if (stream.DataAvailable)
                    {
                        int bytesRead = stream.Read(buffer, 0, buffer.Length);
                        received= Encoding.ASCII.GetString(buffer, 0, bytesRead);
                        Console.WriteLine($"Received: {received.Trim()}");
                    }

                    // Optionally still send messages to client
                    //string message = $"Hello from C# server at {DateTime.Now}\n";
                    if (received== "FIND")
                    {
                        string message = $"CONNECTED";
                        byte[] data = Encoding.ASCII.GetBytes(message);
                        stream.Write(data, 0, data.Length);
                        Console.WriteLine($"Sent: {message.Trim()}");
                    }

                    Thread.Sleep(1000); // Delay
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Client disconnected or error: {ex.Message}");
            }
            finally
            {
                client.Close();
            }
        }
    }
}
